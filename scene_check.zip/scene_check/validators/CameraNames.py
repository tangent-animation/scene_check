import re
import os
import bpy

from scene_check.validators.base_validator import BaseValidator

bd = bpy.data
bc = bpy.context
bp = bpy.context.user_preferences


class CameraNames(BaseValidator):
	'''
	* Checks for temporary geometry in animated scenes.
	'''

	automatic_fix = True

	def __init__(self):
		super(CameraNames, self).__init__()
		self.temp_objects = []

	def process_hook( self ):
		self.temp_objects = [ x for x in bpy.context.scene.objects if 
						 not x.library and x.type in {'MESH','CURVE'} ]

	def automatic_fix_hook(self):
		scene = bpy.context.scene
